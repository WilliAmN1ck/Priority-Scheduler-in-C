/*
 *
 *
 * CS 441/541: CPU Scheduler (Project 1)
 */
#include "scheduler.h"
int quantum = 0;
int * procId;
char *line;
char *cmdArg;
char *fileName;
int numProcesses =0;
int turnAroundTime[];
int waitTime[];
char * fgetsRtn;

int main(int argc, char **argv) {
 
    int count = 0;
    //int length = 0;
    int mode = 0;
    int lineCount = 0;
    //int *sortdProcId = NULL;
    //int *sortdPriority = NULL;
    fd = NULL;
    fgetsRtn = NULL;
    procId = NULL;
    burst = NULL;
    priorities = NULL;
    fd = NULL;
    //reading in cmdline args
    for(count = 1; count < argc; count++) {
        cmdArg = strdup(argv[count]);
        if(!strcmp(cmdArg, "-s")){ //at -s so read the mode
            count++;
            cmdArg = strdup(argv[count]);
            mode = strtol(cmdArg,NULL, 10);
            if(mode <= 0 || mode > 4) {
                //printf("Did not enter a correct mode. \n");
                return -1;
            } else {
                printScheduler(mode);
                //call function to print correct scheduler info
            }
        } else if (!strcmp(cmdArg, "-q")){ //at -q so read the next number
            count++;
            cmdArg = strdup(argv[count]);
            quantum = strtol(cmdArg, NULL, 10);
        } else { //at what should be the name of the .txt file
            fileName = strdup(cmdArg);
            fd = fopen(cmdArg, "r");
        }
        
        if(cmdArg != NULL) {
            free(cmdArg);
            cmdArg = NULL;
        }
    }
    //end of reading in cmdline args
    
    printf("Quantum      : %d\n",quantum);
    printf("Sch. File    : %s\n",fileName);
    readData(); //read in process information from file
    printf("-------------------------------\n");
    arrivalOrder();

    printProcessInfo(); //prints process information segment
    printf("-------------------------------\n");
    sortData(mode);
    
    if(cmdArg != NULL) {
        free(cmdArg);
        cmdArg = NULL;
    }
    freeStuff();
    free(procId);
    free(burst);
    free(priorities);
    fclose(fd);
    return 0;
}

void printProcessInfo() { //prints out the process information segment -- DONE
    printf("Process Information: \n");
    int i = 0;
    for(i = 0; i < numProcesses; i++){
        printf("%-5d\%-5d\%-5d\n" , procId[i*(sizeof(int))], burst[i*(sizeof(int))], priorities[i*(sizeof(int))]);
    }
}

void readData() { //change to return an int if EOF is reached or exception? or just exit(1)
    char *line = NULL;
    int lineCount = 0;
    char *cmdArg = NULL;
    char* fgetsRtn = NULL;
    int tempNum = 0;
    
    if(fd != NULL){ //file was found and can start reading
        line = (char*)(malloc(sizeof(char) * 256));
       
        while(0 == feof(fd)) { //reading in file line by line
            fgetsRtn = fgets(line, 256, fd); //256 = number of possible chars per line
            if(fgetsRtn == NULL){ //end of file
                break;
            }
            if(lineCount == 0 ) { //read in first line of file
                //fgetsRtn = fgets(line, 256, fd); //repeat?
                //do check of line to make sure it is a number
                numProcesses = strtol(line, NULL, 10); //reading in number of processes
                if (fgetsRtn == NULL || numProcesses <= 0) { //error checking file
                    break; //exit(1);
                }
                procId = (int*)(malloc(sizeof(int) * (numProcesses*4))); /*may need to make this bigger*/
                burst = (int*)(malloc(sizeof(int) * (numProcesses*4))); //making size bigger
                priorities = (int*)(malloc(sizeof(int) * (numProcesses*4)));/*so values do not get over written*/
            } else { //reading in a process => proc identifier, cpu burst & priority #'s
                int i = 0;
               
                tempNum = 0;
                cmdArg = strtok(line, " "); //parses line and grabs first number as string

                while(cmdArg != NULL) { //seperating the info in each line
                    //printf("just read the number %s\n",cmdArg);
                    if(cmdArg == NULL) { //nothing in the line
                        //printf("cmd arg is null!");
                        break;
                    }
                    tempNum = strtol(cmdArg, NULL, 10); //convert first number to integer and store in tempNum
                    if(i == 0) { //reading in 3 numbers, this is the first = procId number
                        procId[(lineCount-1)*(sizeof(int))] = tempNum;
                    } else if (i == 1) { //second number == burst
                        burst[(lineCount-1)*(sizeof(int))] = tempNum;
                    } else if (i == 2) { //third number = priority
                        priorities[(lineCount-1)*(sizeof(int))] = tempNum;
                    }
                    i++;
                    cmdArg = strtok(NULL, " "); //prase & grab next number as string = the FIX
                }//end of while
                i = 0;

                tempNum =0;
            }//end of else clause
           
             lineCount++;
            // free(line);
        } //end of reading file
    } else {
        printf("File was not found. \n");
        //return -1;
        exit(-1);
        //print error message and exit w/ negative status
    }
    //free(line); //added
}

void arrivalOrder(){ //DONE
    int i = 0;
    printf("Arrival Order: ");
    for(i = 0; i < numProcesses; i++) {
        if( i < numProcesses-1) {
            printf("%d, ", procId[i*(sizeof(int))]);
        } else {
            printf("%d\n", procId[i*(sizeof(int))]);
        }
    }
}

void sortData(int mode){ //TODO
    /* if waitTime and turnAroundTime do not work, may need to just make them local
        and pass as argument paramets, should not be too hard */
    int **sorted=(int**)(malloc(sizeof(int*)*4));
    int *temp = NULL;
    int *lowest = NULL;
    double totalWait =0; //total waitTime of each process
    double totalTurn = 0; //total turnaroundTime for each process
    double AvgWait = 0.0;
    double AvgTurnAround = 0.0;
    int curProc = 1;
    int previousBurst = 0;
    int waitTime[numProcesses];
    int turnAroundTime[numProcesses];
    int j = 0;
    for(j = 0; j < numProcesses; j++) { //initialize arrays contents to 0
        waitTime[j] =0;
        turnAroundTime[j] = 0;
    }
    printf("Running...\n");
    printf("##################################################\n");
    /*Time to sort the data then figure out the average waiting and turnaround time
     to sort for modes:
     1) EZ: use the above waitTime procedure and find turnaroundTimes by WaitTime-Burst
     2) go through burst times and save the lowest burst # into a variable, then calculate waiting(similar equation to SJF) and turnaround time(same as SJF) -- make sure to find an initial value for the lowest burst # into variable then after first loop, just have to make sure the burst #'s in the array are >= the last one
     3) using priority array/pointer, go through using similar algorithm as 2 except with the priority
     4) use the saved quantum value to execute each job's burst (hardest one) and calculate waiting time and turnaround time -- not similar to the others. Maybe copy the burst array to another temporary array or else just subtract the burst numbers until at 0. **IMPORTANT** need to check if the current process' burst length is less than the quantum and then must bring in a new process for the burst UNTIL the quantum time has been reached and must start again.
     */
    if(mode == 1) {//FCFS --DONE
        //this whole thing could be a method that is called...
        int i = 0;
        for(i = 0; i< numProcesses; i++) {
            curProc = i+1;
            previousBurst = burst[i*(sizeof(int))];
            while(curProc < numProcesses) {
                waitTime[curProc] = waitTime[curProc] + previousBurst;

                curProc = curProc + 1;
            }
            turnAroundTime[i] = waitTime[i] + burst[i*(sizeof(int))];
        }
        //Method for printing out the stats.....
        printf("# #  CPU  Pri    W    T\n");
        i = 0;
        for(i = 0; i < numProcesses; i++){ //print waiting time and turnaroundtime
            printf("# %-5d%-5d%-5d%-5d\%-5d\n" ,procId[i*sizeof(int)], burst[i*sizeof(int)],priorities[i*sizeof(int)],waitTime[i], turnAroundTime[i]);
            totalWait = totalWait + waitTime[i];
            totalTurn = totalTurn + turnAroundTime[i];
            //printf("totalWait is: %f and totalTurn is: %f\n", totalWait, totalTurn);
        }
        AvgWait = (totalWait/numProcesses);
        AvgTurnAround = (totalTurn/numProcesses);
        printf("##################################################\n");
        //AVG waiting time....
        
        printf("# Avg. Waiting time   :  %2.2f\n", AvgWait);
        //AVG turnaround time....
        printf("# Avg. Turnaround Time:  %2.2f\n", AvgTurnAround);
        printf("##################################################\n");
        
    } else if (mode == 2) {//SJF
       
        int i = 0;
        int j = 0;
        for(i=0; i< numProcesses; i++) {
            sorted[i] = &burst[i*sizeof(int)];
            //printf("just copied over %d\n", *sorted[i]);
        }
        i = 0;
        for(i = 0; i < numProcesses; i ++) {
            lowest = sorted[i];
            j = 0;
            for(j = i+1; j <numProcesses;j++) {
                if(*sorted[j] < *lowest) {
                    temp = lowest;
                    sorted[i] = sorted[j];
                    sorted[j] = lowest;
                    //printf("just swapped %d (new lower) for %d\n", *sorted[i], *sorted[j]);
                    lowest = sorted[i];
                }
            }
        }
        i = 0;
        for(i = 0; i<numProcesses; i++) {
            //printf("at pos %d the num is %d\n",i,*sorted[i]);
        }
        calcTurnAround(sorted);
    } else if (mode == 3) {//priority
        int i = 0;
        int j = 0;
        for(i=0; i< numProcesses; i++) {
            sorted[i] = &priorities[i*sizeof(int)];
            //printf("just copied over %d\n", *sorted[i]);
        }
        i = 0;
        for(i = 0; i < numProcesses; i ++) {
            lowest = sorted[i];
            j = 0;
            for(j = i+1; j <numProcesses;j++) {
                if(*sorted[j] < *lowest) {
                    temp = lowest;
                    sorted[i] = sorted[j];
                    sorted[j] = lowest;
                    //printf("just swapped %d (new lower) for %d\n", *sorted[i], *sorted[j]);
                    lowest = sorted[i];
                }
            }
        }
        i = 0;
        for(i = 0; i<numProcesses; i++) {
            //printf("at pos %d the num is %d\n",i,*sorted[i]);
        }
        calcTurnAround(sorted);
    } else { //mode ==4 ==> RR
        int tempBursts[numProcesses];
        int leftOverQuantum = 0;
        int i = 0;
        for(i = 0; i < numProcesses; i++) {
            tempBursts[i] = burst[i*sizeof(int)];
            //printf("just copied burst over that was a burst of: %d\n",tempBursts[i]);
        }
        i = 0;
        int l = 0;
        leftOverQuantum = quantum;
        for(i=0; i<numProcesses; i++) {
            while(tempBursts[i] > 0 && tempBursts[i] < leftOverQuantum) {//will need to use the next burst in the array too
                leftOverQuantum = quantum - tempBursts[i];
                //turnAroundTime[i] = turnAroundTime[i] + tempBursts[i]; //may not need
                tempBursts[i] = 0;
                //printf("at %d and it didnt use the whole burst/quantum\n",i);
                for(l = 0; l < numProcesses; l++) { //increment wait times
                    if(tempBursts[l] != 0) { //only if there is a burst left
                        //and it was not the burst that just went
                        waitTime[l] = waitTime[l] + (quantum - leftOverQuantum);
                    }
                }
                i++;
            } //end of while loop
            if(tempBursts[i] > 0 && tempBursts[i] >= quantum && tempBursts[i] != 0) { //only do one burst
                
                //turnAroundTime[i] = turnAroundTime[i] + quantum;
                tempBursts[i] = tempBursts[i] - quantum;
                //printf("at quantum %d and it has %d burst left\n", i,tempBursts[i]);
                for(l = 0; l < numProcesses; l++) { //increment wait times
                    if(tempBursts[l] != 0 && i != l) {
                        waitTime[l] = waitTime[l] + quantum;
                    }
                }
            } else if (tempBursts[i] == 0){ //no bursts left in this one so check if any left
                //printf("made it here\n");
                //need to check rest of array to see if any bursts left
                for(l = 0; l < numProcesses; l++) {
                    if(tempBursts[l] != 0) {
                        i = 0; //start going back thru again
                    }
                }
            }
            leftOverQuantum = quantum;
        }// end of outer for loop
        for(i=0; i< numProcesses; i++) {
            turnAroundTime[i] = burst[i*sizeof(int)] + waitTime[i];
        }
        //Method for printing the data
        printf("# #  CPU  Pri    W    T\n");
        i = 0;
        for(i = 0; i < numProcesses; i++){ //print waiting time and turnaroundtime
            printf("# %-5d%-5d%-5d%-5d\%-5d\n" ,procId[i*sizeof(int)], burst[i*sizeof(int)],priorities[i*sizeof(int)],waitTime[i], turnAroundTime[i]);
            totalWait = totalWait + waitTime[i];
            totalTurn = totalTurn + turnAroundTime[i];
            //printf("totalWait is: %f and totalTurn is: %f\n", totalWait, totalTurn);
        }
        AvgWait = (totalWait/numProcesses);
        AvgTurnAround = (totalTurn/numProcesses);
        printf("##################################################\n");
        //AVG waiting time....
        
        printf("# Avg. Waiting time   :  %2.2f\n", AvgWait);
        //AVG turnaround time....
        printf("# Avg. Turnaround Time:  %2.2f\n", AvgTurnAround);
        printf("##################################################\n");
    }
}

void printScheduler(int x) { //DONE
    //printf("made it again\n");
    char phrase[27] = "Scheduler    : ";
    //printf("%s\n", phrase);
    if(x == 1) { //first come first served
        strcat(phrase, "1 FCFS");
    } else if (x == 2) { // shortest job first
        strcat(phrase, "2 SJF");
    } else if (x == 3) { // priority
        strcat(phrase, "3 Priority");
    } else { //mode == 4 == round robin
        strcat(phrase, "4 RR");
    }
    printf("%s \n", phrase);
}

void calcTurnAround(int **array) {
    int waitTime[numProcesses];
    int turnAroundTime[numProcesses];
    double totalWait =0; //total waitTime of each process
    double totalTurn = 0; //total turnaroundTime for each process
    double AvgWait = 0.0;
    double AvgTurnAround = 0.0;
    int j = 0;
    for(j = 0; j<numProcesses; j++){
        waitTime[j] = 0;
        turnAroundTime[j] = 0;
    }
    int curProc = 0;
    int previousBurst = 0;
    int i = 0;
    for(i = 0; i< numProcesses; i++) {
        curProc = i+1;
        previousBurst = *array[i];
        while(curProc < numProcesses) {
            waitTime[curProc] = waitTime[curProc] + previousBurst;
            //printf("just incremented the waitTime for proc %d and waitTime is now: %d\n", curProc, waitTime[curProc]);
            curProc = curProc + 1;
        }
        turnAroundTime[i] = waitTime[i] + *array[i];
        //printf("turnaroundtime incremented for %d and turnAroundtime is: %d\n",i,turnAroundTime[i]);
    }
    i = 0;
    int newWaitTime[numProcesses];
    int newTurnTime[numProcesses];
    for(i = 0; i< numProcesses; i++) {
        newWaitTime[i]= 0;
        newTurnTime[i] = 0;
        j = 0;
        for(j = 0; j < numProcesses; j++) {
            if(array[i] == &burst[j*sizeof(int)]) {
                newWaitTime[i] = waitTime[j];
                newTurnTime[i] = turnAroundTime[j];
            }
        }
    }
    
    int temp = 0;
    for(int i = 0; i< numProcesses; i = i + 3) { //rearrange ordering cuz out of order
        if(i % 2 == 0) {
            temp = newWaitTime[i];
            newWaitTime[i] = newWaitTime[i+2];
            newWaitTime[i+2] = temp;
            temp = newTurnTime[i];
            newTurnTime[i] = newTurnTime[i+2];
            newTurnTime[i+2] = temp;
            
        } else if(i%3!=0){
            
            temp = newWaitTime[i];
            newWaitTime[i] = newWaitTime[i+1];
            newWaitTime[i+1] = temp;
            temp = newTurnTime[i];
            newTurnTime[i] = newTurnTime[i+1];
            newTurnTime[i+1] = temp;
        }
    }

    printf("# #  CPU  Pri    W    T\n");
    i = 0;
    for(i = 0; i < numProcesses; i++){ //print waiting time and turnaroundtime
        printf("# %-5d%-5d%-5d%-5d\%-5d\n" ,procId[i*sizeof(int)], burst[i*sizeof(int)],priorities[i*sizeof(int)],newWaitTime[i], newTurnTime[i]);
        totalWait = totalWait + newWaitTime[i];
        totalTurn = totalTurn + newTurnTime[i];
        //printf("totalWait is: %f and totalTurn is: %f\n", totalWait, totalTurn);
    }
    AvgWait = (totalWait/numProcesses);
    AvgTurnAround = (totalTurn/numProcesses);
    printf("##################################################\n");
    //AVG waiting time....
    
    printf("# Avg. Waiting time   :  %2.2f\n", AvgWait);
    //AVG turnaround time....
    printf("# Avg. Turnaround Time:  %2.2f\n", AvgTurnAround);
    printf("##################################################\n");
    
}

void freeStuff() {
    if(procId != NULL) {
        free(procId);
        procId = NULL;
    }
    if (burst != NULL) {
        free(burst);
        burst = NULL;
    }
    if(priorities != NULL) {
        free(priorities);
        priorities = NULL;
    }
    if(fgetsRtn != NULL){
        free(fgetsRtn);
        fgetsRtn = NULL;
    }
}
/*int* sortBurst(int *sorted) {
    printf("MADE IT TO SORTED METHOD\n");
    sorted = malloc(sizeof(int*)* (numProcesses*2+1));
    int i = 0;
    int lowest = 0;
    int *lastLowest = NULL;
    for(i = 0; i < numProcesses-1; i++) { //copy and sort the new array
        lowest = burst[i*sizeof(int)];
        lastLowest = &lowest;
        int j = i+1;
        for(j = i + 1; j < numProcesses; j++) {
            if(burst[j*sizeof(int)] < lowest && &burst[j*sizeof(int)] == lastLowest && burst[j*sizeof(int)] >= *lastLowest) {
                lowest = burst[j*sizeof(int)];
                printf("new lowest is %d\n",lowest);
            }
        }
        sorted[i] = lowest;
    }
}*/
