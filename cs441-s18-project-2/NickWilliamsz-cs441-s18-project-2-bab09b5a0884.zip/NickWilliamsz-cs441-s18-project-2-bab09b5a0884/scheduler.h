/*
 * 
 *
 * CS 441/541: CPU Scheduler (Project 1)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>


/******************************
 * Defines
 ******************************/


/******************************
 * Structures
 ******************************/
struct Process {
    char* saying;
};


/******************************
 * Global Variables
 ******************************/
FILE *fd; //the file to read from -- delete?
char *fgetsRtn; //for checking if at end of file (null check) -- delete?
  //or else can use feof(FILE *fd) for checking when at EOF
//char *line;//variable to temporarily store a readline in
int numProcesses; //number of processes in the file
int *procId; //array?
int *burst; //array?
int *priorities; //array?
int waitTime[];//array
int turnAroundTime[]; //array
int quantum;

/******************************
 * Function declarations
 ******************************/
void printProcessInfo(); //prints process info & maybe arrival order before it
void readData(); //reads in the file data
void sortData();
void printScheduler(int x);
void arrivalOrder();
void calcTurnAround(int **array);
void freeStuff();
